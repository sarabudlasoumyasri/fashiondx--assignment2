running 
localhost:8080
localhost:8080/api
loacalhost:8080/api/contacts